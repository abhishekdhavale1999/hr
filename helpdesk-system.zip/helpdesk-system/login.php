<?php 
include 'init.php';
if($users->isLoggedIn()) {
    header('Location: ticket.php');
}
$errorMessage = $users->login();
include('inc/header.php');
?>
<title>Intent HR</title>
<?php include('inc/container.php');?>
<?php include('inc/container.php');?>
<style>
    body {
        background-image: url('http://192.168.1.176/helpdesk-system/image/22.jpg'); 
        background-size: cover;
        background-position: center;
    }       

    .container.contact {
        display:flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    
    .panel-title {
        text-align: center; 
        border-color: black;
        border-radius: 50px; 
    }

    .panel.panel-info {
        border-color:black;
        background:white;
    }
    .Orange {
        color:black;
    }
    .blue{
        color:black;
    }
</style>
<body>
    <div class="container contact">           
        <div class="col-md-6">                    
            <div class="panel panel-info">
                <div class="panel-heading" style="background:white; color:black;">
                    <img src="http://192.168.1.176/helpdesk-system/image/logo.png" alt="Logo" style="height:90px; margin-left:170px;">
                    <div class="panel-title"><h2><b>Intent-Amplify HR Service Desk <b><h2></div>                        
                </div> 
                <div style="padding-top:20px" class="panel-body" >
                    <?php if ($errorMessage != '') { ?>
                        <div id="login-alert" class="alert alert-danger col-sm-12"><?php echo $errorMessage; ?></div>                            
                    <?php } ?>
                    <form id="loginform" class="form-horizontal" role="form" method="POST" action="">                                    
                        <div style="margin-bottom: 20px" class="input-group">
                            <span class="input-group-addon" style="border: 1px solid #000;"><i class="glyphicon glyphicon-envelope Orange"></i></span>
                            <input type="text" class="form-control" id="email" name="email" placeholder="Please Enter Email" style="background:white; border: 1px solid #000;" required>                                        
                        </div>                                

                        <div style="margin-bottom: 20px" class="input-group">
                            <span class="input-group-addon" style="border: 1px solid #000;"><i id="togglePassword" class="glyphicon glyphicon-eye-close blue"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" style="border: 1px solid #000;" required>
                        </div>

                        <div style="margin-top:30px" class="form-group">                               
                            <div class="col-sm-12 controls text-center"> 
                                <input type="submit" name="login" value="Login" class="btn btn-success" style="border: 2px solid #000;color:black">						  
                            </div>
                        </div>					
                    </form>   
                </div>                     
            </div>  
            <footer>
                <div class="text-center" style="margin-left:30px;color:white;">
                    &copy; <?php echo date("Y"); ?> Intent-Amplify HR Department.All rights reserved.
                </div>
            </footer>
        </div>
    </div>
    
    <script>
        document.getElementById('togglePassword').addEventListener('click', function() {
            var passwordField = document.getElementById('password');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                this.classList.remove('glyphicon-eye-close');
                this.classList.add('glyphicon-eye-open');
            } else {
                passwordField.type = 'password';
                this.classList.remove('glyphicon-eye-open');
                this.classList.add('glyphicon-eye-close');
            }
        });
    </script>
</body>
<?php include('inc/footer.php');?>
