
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="fas fa-clipboard"></span>
                <span class="fas fa-briefcase"></span>
                <span class="fas fa-address-book"></span> 
            </button>
            
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li id="ticket"><a href="ticket.php" style="color:black;"><h3>Ticket<h3></a></li>
                <?php if(isset($_SESSION["admin"])) { ?>
                    <li id="department"><a href="department.php" style="color:black;"><h3>Department<h3></a></li>
                    <li id="user"><a href="user.php" style="color:black;"><h3>Users<h3></a></li>               
                <?php } ?>                       
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: black;">
                <span class="label label-pill label-danger count"></span> 
               <img src="http://192.168.1.176/helpdesk-system/image/default.jpg?email=<?php echo md5($user['email']); ?>" width="30px">
             <?php if(isset($_SESSION["userid"])) { echo $user['name']; } ?>
          </a>
                    <ul class="dropdown-menu">                    
                        <li><a href="logout.php" style="color:black;"class="btn btn-danger"><b>Logout<b></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
