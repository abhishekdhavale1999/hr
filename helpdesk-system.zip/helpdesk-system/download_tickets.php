<?php

$pdo = new PDO('mysql:host=localhost;dbname=helpdesk_system', 'root', '');

$stmt = $pdo->query("SELECT hd_tickets.*, hd_users.name 
                     FROM `hd_tickets` 
                     INNER JOIN `hd_users` 
                     ON hd_tickets.user = hd_users.id");

$ticketsData = $stmt->fetchAll(PDO::FETCH_ASSOC);


$filename = 'Intent_amplify_tickets_report_' . date('Y-m-d') . '.csv';

ob_start();

// Create CSV file
$file = fopen('php://output', 'w');

// Add headers
$headers = ['Sr.No','Ticket ID', 'Created By','Subject',   'Created', 'Status'];
fputcsv($file, $headers);


foreach ($ticketsData as $ticket) {
    date_default_timezone_set('Asia/Kolkata');
    $timestamp = $ticket['date'];
    $date = date("d-m-Y", $timestamp);

    if($ticket['resolved']==0){
        $status = 'Open';
    }elseif($ticket['resolved']==1){
        $status = 'close';
    }

    $rowData = [
        isset($ticket['id']) ? $ticket['id'] : '',
        isset($ticket['uniqid']) ? $ticket['uniqid'] : '',
        isset($ticket['name']) ? $ticket['name'] : '',
        isset($ticket['title']) ? $ticket['title'] : '',
        
        isset($ticket['date']) ? $date : '',
        isset($ticket['resolved']) ? $status : ''
    ];
    fputcsv($file, $rowData);
}


fclose($file);

try {
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

   
    ob_end_flush();
    exit;
} catch (Exception $e) {
    
    ob_end_clean();
    echo 'Error: ' . $e->getMessage();
}
?>