<?php
include 'init.php'; 
$newTicketsCount = 0;


$sql = "SELECT COUNT(*) AS new_tickets_count FROM hd_tickets WHERE status = 'new'";
$result = $db->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $newTicketsCount = $row['new_tickets_count'];
} else {
    
    echo "Error: " . $db->error;
}

echo $newTicketsCount;
?>
