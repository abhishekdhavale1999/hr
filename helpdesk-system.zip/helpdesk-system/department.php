<?php 
include 'init.php'; 
if(!$users->isLoggedIn()) {
	header("Location: login.php");	
}
include('inc/header.php');
$user = $users->getUserInfo();
?>

<title>Intent HR</title>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="js/general.js"></script>
<script src="js/department.js"></script>
<link rel="stylesheet" href="css/style.css" />
<?php include('inc/container.php');?>
<div class="container">	
	<div class="row home-sections" align="center">
    <img src="http://192.168.1.176/helpdesk-system/image/logo.png" alt="Logo" width="160px" >
	<h2><b> Department<b></h2>	
	<body>
    <style>
        body {
            background-image: url('http://192.168.1.176/helpdesk-system/image/121.jpg'); 
            background-color: #FFF5EE;
            background-size:cover;
            font-family: "Times New Roman", Times, serif;
        }
        .container {
            width: 100%;
            margin:0 auto;
        }
        .home-sections {
          
            padding: 15px;
            margin-top: 15px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        
        .panel-heading h3.panel-title {
            margin: 0;
            font-size:10px;
        }
        .btn-success {
            background-color: #28a745;
            border: 1px solid black;
            color: black;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            float: right;
        }
        .btn-success:hover {
            background-color: green;
        }
        .btn-info {
            background-color: #17a2b8;
            border: none;
            color: black;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-info:hover {
            background-color: #138496;
        }
        
        table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px; /* Adjust as needed */
}

th, td {
    border: 1px solid black; 
    padding: 12px; 
    text-align: left;
}

th {
    background-color:#6CB4EE;
    color: black; 
}

td {
   background-color:white;
    color:black; 
}

th:first-child, td:first-child {
    border-left: none;
}

th:last-child, td:last-child {
    border-right: none;
}
    </style>

	<?php include('menus.php'); ?>		
	</div> 
	
	<div class="panel-heading">
		<div class="row">
			<div class="col-md-10">
				<h3 class="panel-title"></h3>
			</div>
			<div class="col-md-2" align="right">
				<button type="button" name="add" id="addDepartment" class="btn btn-success" style="color: black;"><b>Add Department<b></button>
			</div>
		</div>
	</div>
			
	<table id="listDepartment" class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>Sr.No</th>
				<th>Department</th>					
				<th>Status</th>
				<th>Edit</th>
				<th>Delete</th>									
			</tr>
		</thead>
	</table>
	
	<div id="departmentModal" class="modal fade">
		<div class="modal-dialog">
			<form method="post" id="departmentForm">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title"><i class="fa fa-plus"></i><b> Add Department<b></h4>
					</div>
					<div class="modal-body">
						<div class="form-group"
							<label for="department" class="control-label"><b>Department<b></label>
							<input type="text" class="form-control" id="department" name="department" placeholder="department" required>			
						</div>
						
						<div class="form-group">
							<label for="status" class="control-label"><b>Status<b></label>				
							<select id="status" name="status" class="form-control">
							<option value="1">Active </option>				
							<option value="0">Inactive</option>	
							</select>						
						</div>						
						
					</div>
					<div class="modal-footer">
						<input type="hidden" name="departmentId" id="departmentId" />
						<input type="hidden" name="action" id="action" value="" />
						<input type="submit" name="save" id="save" class="btn btn-info" value="Save" />
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>	
<?php include('inc/footer.php');?>